
let title = "Product Purchase Bill";
    document.getElementById("title").innerHTML = title;

let bill = "Bill Summary";
    document.getElementById("bill").innerHTML = bill;

let ta = "Total Amount :";
    document.getElementById("ta").innerHTML = ta;

let dis = "Discount:";
    document.getElementById("dis").innerHTML = dis;

let ap = "Amount Payable:";
    document.getElementById("ap").innerHTML = ap;

function calculateBill() {

    let productName = document.getElementById("productName");
    let productPrice = parseFloat(document.getElementById("productPrice").value);
    let quantity = parseInt(document.getElementById("quantity").value);
    let discount = parseFloat(document.getElementById("discount").value);
     
    let total = productPrice * quantity;
    let discountAmount = (total * discount) / 100;
    let payableAmount = total - discountAmount;

    document.getElementById("total").textContent = total.toFixed(2);
    document.getElementById("totalAmount").textContent = total.toFixed(2);
    document.getElementById("discountAmount").textContent = discountAmount.toFixed(2);
    document.getElementById("payableAmount").textContent = payableAmount.toFixed(2);
}