let title = "Simple Interest Calculator ";
    document.getElementById("title").innerHTML = title;
    

function calculate() {
            var principal = parseFloat(document.getElementById('principal').value);
            var rate = parseFloat(document.getElementById('rate').value);
            var years = parseFloat(document.getElementById('years').value);

            var accruedAmount = principal * (1 + (rate/100) * years);
            var interestAmount = accruedAmount - principal;

            document.getElementById('accruedAmount').textContent = accruedAmount.toFixed(2);
            document.getElementById('interestAmount').textContent = interestAmount.toFixed(2);
            document.getElementById('result');
        }