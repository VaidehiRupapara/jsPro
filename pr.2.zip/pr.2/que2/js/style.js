let choice = 8;
var season = "Winter";
var season1 = "Summer";
var season2 = "Moonsoon";
var unvalid = "unvalid choice";

switch(choice)
                {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        document.getElementById("season").innerHTML = season;
                    break;

                    case 5:
                    case 6:
                    case 7:
                    case 8:
                        document.getElementById("season1").innerHTML = season1;
                    break;

                    case 9:
                    case 10:
                    case 11:
                    case 12:
                        document.getElementById("season2").innerHTML = season2;
                    break;

                    default :
                        document.getElementById("unvalid").innerHTML = unvalid;
                }