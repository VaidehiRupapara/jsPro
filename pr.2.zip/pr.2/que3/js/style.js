let ic = "Interest Calculator";
    document.getElementById("ic").innerHTML = ic;


function calculateInterest() {
            var principal = parseFloat(document.getElementById("principal").value);
            var years = parseInt(document.getElementById("years").value);
            var rate;

            if (years > 3 && years <= 5) {
                rate = 3;
            } else if (years > 5 && years <= 8) {
                rate = 5;
            } else if (years > 8 && years <= 12) {
                rate = 12;
            } else {
                rate = 15;
            }

            var interest = (principal * rate * years) / 100;
            var totalAmount = principal + interest;

            var resultElement = document.getElementById("result");
            resultElement.innerHTML = "<h3>Interest Rate: " + rate + "%</h3>";
            resultElement.innerHTML += "<h3>Total Interest: " + interest.toFixed(2) + "</h3>";
            resultElement.innerHTML += "<h3>Total Amount: " + totalAmount.toFixed(2) + "</h3>";
        } 